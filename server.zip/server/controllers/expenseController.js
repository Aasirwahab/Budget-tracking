const Expense = require('../models/expenseModel');

exports.addExpense = async (req, res) => {
  try {
    const { amount, currency, category, date, notes } = req.body;
    const userId = req.user._id; // Extract user ID from the request
    const newExpense = new Expense({ user_id: userId, amount, currency, category, date, notes });
    await newExpense.save();
    res.status(201).json({ success: true, message: 'Expense added successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to add expense', error });
  }
};
