const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const colors = require("colors");
const morgan = require("morgan");
const connectDB = require("./config/db");

// Load environment variables
dotenv.config();

// Confirm that MONGO_URL is loaded correctly
console.log(`MONGO_URL: ${process.env.MONGO_URL}`);

// Connect to MongoDB
connectDB();

// Create Express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// Routes
app.use("/api/v1/auth",require("./routes/userRoutes"));
app.use("/api/v1/expenses", require("./routes/expenseRoutes"));

// Get port from environment variables or default to 8080
const PORT = process.env.PORT || 8080;

// Start server
app.listen(PORT, () => {
  console.log(`Server Running on PORT ${PORT}`.bgGreen.white);
});

